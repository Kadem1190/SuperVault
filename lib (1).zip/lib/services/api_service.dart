import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/user_model.dart';

class ApiService {
  // Base URL for the API
  static const String baseUrl = 'https://your-clever-cloud-app.cleverapps.io/api';
  
  // Authentication
  static Future<User?> login(String email, String password) async {
    try {
      print('Sending login request to: $baseUrl/auth/login.php');
      print('Email: $email, Password: $password');
      
      final response = await http.post(
        Uri.parse('$baseUrl/auth/login.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email, 'password': password}),
      );
      
      print('Login response status: ${response.statusCode}');
      print('Login response body: ${response.body}');
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return User(
          id: data['id'],
          name: data['name'],
          email: data['email'],
          role: data['role'] == 'admin' ? UserRole.admin : UserRole.staff,
          avatarUrl: data['avatar_url'],
        );
      } else {
        // Parse error message if available
        try {
          final errorData = jsonDecode(response.body);
          print('Login error: ${errorData['message']}');
        } catch (e) {
          print('Could not parse error response: $e');
        }
      }
    } catch (e) {
      print('Login exception: $e');
    }
    return null;
  }
  
  // Products
  static Future<List<Map<String, dynamic>>> getProducts({
    String? category,
    String? search,
    String? userId,
  }) async {
    try {
      String url = '$baseUrl/products/read.php';
      
      // Add query parameters if provided
      List<String> queryParams = [];
      if (category != null && category != 'All Categories') {
        queryParams.add('category=${Uri.encodeComponent(category)}');
      }
      if (search != null && search.isNotEmpty) {
        queryParams.add('search=${Uri.encodeComponent(search)}');
      }
      if (userId != null) {
        queryParams.add('user_id=${Uri.encodeComponent(userId)}');
      }
      
      if (queryParams.isNotEmpty) {
        url += '?' + queryParams.join('&');
      }
      
      print('Fetching products from: $url');
      final response = await http.get(Uri.parse(url));
      print('Products response status: ${response.statusCode}');
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print('Products found: ${data['records'].length}');
        return List<Map<String, dynamic>>.from(data['records']);
      } else {
        print('Failed to get products: ${response.body}');
      }
    } catch (e) {
      print('Get products error: $e');
    }
    
    return [];
  }
  
  // Create product
  static Future<bool> createProduct(Map<String, dynamic> productData) async {
    try {
      // Generate a unique ID for the product
      productData['id'] = DateTime.now().millisecondsSinceEpoch.toString();
      
      final response = await http.post(
        Uri.parse('$baseUrl/products/create.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(productData),
      );
      
      return response.statusCode == 201;
    } catch (e) {
      print('Create product error: $e');
      return false;
    }
  }
  
  // Update product
  static Future<bool> updateProduct(Map<String, dynamic> productData) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/products/update.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(productData),
      );
      
      return response.statusCode == 200;
    } catch (e) {
      print('Update product error: $e');
      return false;
    }
  }
  
  // Delete product
  static Future<bool> deleteProduct(String id, String userId) async {
    try {
      final response = await http.delete(
        Uri.parse('$baseUrl/products/delete.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'id': id,
          'user_id': userId,
        }),
      );
      
      return response.statusCode == 200;
    } catch (e) {
      print('Delete product error: $e');
      return false;
    }
  }
  
  // Warehouses
  static Future<List<Map<String, dynamic>>> getWarehouses({
    String? search,
    String? userId,
  }) async {
    try {
      String url = '$baseUrl/warehouses/read.php';
      
      // Add query parameters if provided
      List<String> queryParams = [];
      if (search != null && search.isNotEmpty) {
        queryParams.add('search=${Uri.encodeComponent(search)}');
      }
      if (userId != null) {
        queryParams.add('user_id=${Uri.encodeComponent(userId)}');
      }
      
      if (queryParams.isNotEmpty) {
        url += '?' + queryParams.join('&');
      }
      
      final response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return List<Map<String, dynamic>>.from(data['records']);
      }
    } catch (e) {
      print('Get warehouses error: $e');
    }
    
    return [];
  }
  
  // Inventory
  static Future<List<Map<String, dynamic>>> getInventory({
    String? warehouse,
    String? category,
    String? search,
    String? userId,
  }) async {
    try {
      String url = '$baseUrl/inventory/read.php';
      
      // Add query parameters if provided
      List<String> queryParams = [];
      if (warehouse != null && warehouse != 'All Warehouses') {
        queryParams.add('warehouse=${Uri.encodeComponent(warehouse)}');
      }
      if (category != null && category != 'All Categories') {
        queryParams.add('category=${Uri.encodeComponent(category)}');
      }
      if (search != null && search.isNotEmpty) {
        queryParams.add('search=${Uri.encodeComponent(search)}');
      }
      if (userId != null) {
        queryParams.add('user_id=${Uri.encodeComponent(userId)}');
      }
      
      if (queryParams.isNotEmpty) {
        url += '?' + queryParams.join('&');
      }
      
      final response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return List<Map<String, dynamic>>.from(data['records']);
      }
    } catch (e) {
      print('Get inventory error: $e');
    }
    
    return [];
  }
  
  // Update inventory
  static Future<bool> updateInventory(Map<String, dynamic> inventoryData) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/inventory/update.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(inventoryData),
      );
      
      return response.statusCode == 200;
    } catch (e) {
      print('Update inventory error: $e');
      return false;
    }
  }
  
  // Transactions
  static Future<List<Map<String, dynamic>>> getTransactions({
    String? type,
    String? warehouse,
    String? search,
    String? userId,
  }) async {
    try {
      String url = '$baseUrl/transactions/read.php';
      
      // Add query parameters if provided
      List<String> queryParams = [];
      if (type != null && type != 'All Types') {
        queryParams.add('type=${Uri.encodeComponent(type)}');
      }
      if (warehouse != null && warehouse != 'All Warehouses') {
        queryParams.add('warehouse=${Uri.encodeComponent(warehouse)}');
      }
      if (search != null && search.isNotEmpty) {
        queryParams.add('search=${Uri.encodeComponent(search)}');
      }
      if (userId != null) {
        queryParams.add('user_id=${Uri.encodeComponent(userId)}');
      }
      
      if (queryParams.isNotEmpty) {
        url += '?' + queryParams.join('&');
      }
      
      final response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return List<Map<String, dynamic>>.from(data['records']);
      }
    } catch (e) {
      print('Get transactions error: $e');
    }
    
    return [];
  }
  
  // Create transaction
  static Future<bool> createTransaction(Map<String, dynamic> transactionData) async {
    try {
      // Generate a unique ID for the transaction
      transactionData['id'] = DateTime.now().millisecondsSinceEpoch.toString();
      
      final response = await http.post(
        Uri.parse('$baseUrl/transactions/create.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(transactionData),
      );
      
      return response.statusCode == 201;
    } catch (e) {
      print('Create transaction error: $e');
      return false;
    }
  }
  
  // Activity Logs
  static Future<List<Map<String, dynamic>>> getActivityLogs({
    String? activity,
    String? user,
    String? search,
  }) async {
    try {
      String url = '$baseUrl/activity_logs/read.php';
      
      // Add query parameters if provided
      List<String> queryParams = [];
      if (activity != null && activity != 'All Activities') {
        queryParams.add('activity=${Uri.encodeComponent(activity)}');
      }
      if (user != null && user != 'All Users') {
        queryParams.add('user=${Uri.encodeComponent(user)}');
      }
      if (search != null && search.isNotEmpty) {
        queryParams.add('search=${Uri.encodeComponent(search)}');
      }
      
      if (queryParams.isNotEmpty) {
        url += '?' + queryParams.join('&');
      }
      
      final response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return List<Map<String, dynamic>>.from(data['records']);
      }
    } catch (e) {
      print('Get activity logs error: $e');
    }
    
    return [];
  }
  
  // Analytics - Stock Movement
  static Future<List<Map<String, dynamic>>> getStockMovement({
    String? warehouse,
    String? category,
    String? timeRange,
    String? userId,
  }) async {
    try {
      String url = '$baseUrl/analytics/stock_movement.php';
      
      // Add query parameters if provided
      List<String> queryParams = [];
      if (warehouse != null && warehouse != 'All Warehouses') {
        queryParams.add('warehouse=${Uri.encodeComponent(warehouse)}');
      }
      if (category != null && category != 'All Categories') {
        queryParams.add('category=${Uri.encodeComponent(category)}');
      }
      if (timeRange != null) {
        queryParams.add('timeRange=${Uri.encodeComponent(timeRange)}');
      }
      if (userId != null) {
        queryParams.add('user_id=${Uri.encodeComponent(userId)}');
      }
      
      if (queryParams.isNotEmpty) {
        url += '?' + queryParams.join('&');
      }
      
      final response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return List<Map<String, dynamic>>.from(data['records']);
      }
    } catch (e) {
      print('Get stock movement error: $e');
    }
    
    return [];
  }
}