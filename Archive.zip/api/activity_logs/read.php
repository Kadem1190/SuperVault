<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Include database and activity log model
include_once '../config/database.php';
include_once '../models/activity_log.php';

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Instantiate activity log object
$activity_log = new ActivityLog($db);

// Get query parameters
$activity = isset($_GET['activity']) ? $_GET['activity'] : null;
$user = isset($_GET['user']) ? $_GET['user'] : null;
$search = isset($_GET['search']) ? $_GET['search'] : null;

// Query activity logs
$stmt = $activity_log->read($activity, $user, $search);
$num = $stmt->rowCount();

// Check if more than 0 record found
if($num > 0) {
    // Activity logs array
    $logs_arr = array();
    $logs_arr["records"] = array();
    
    // Retrieve table contents
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        
        $log_item = array(
            "id" => $id,
            "user_id" => $user_id,
            "user_name" => $user_name,
            "user_role" => $user_role,
            "activity_type" => $activity_type,
            "entity_type" => $entity_type,
            "entity_id" => $entity_id,
            "entity_name" => $entity_name,
            "description" => $description,
            "timestamp" => $timestamp
        );
        
        array_push($logs_arr["records"], $log_item);
    }
    
    // Set response code - 200 OK
    http_response_code(200);
    
    // Show activity logs data in json format
    echo json_encode($logs_arr);
} else {
    // Set response code - 404 Not found
    http_response_code(404);
    
    // Tell the user no activity logs found
    echo json_encode(array("message" => "No activity logs found."));
}
?>