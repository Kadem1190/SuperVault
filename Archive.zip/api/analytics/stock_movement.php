<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Include database
include_once '../config/database.php';
include_once '../models/activity_log.php';

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Get query parameters
$warehouse = isset($_GET['warehouse']) ? $_GET['warehouse'] : null;
$category = isset($_GET['category']) ? $_GET['category'] : null;
$timeRange = isset($_GET['timeRange']) ? $_GET['timeRange'] : 'Last 7 Days';
$user_id = isset($_GET['user_id']) ? $_GET['user_id'] : null;

// Log the activity if user_id is provided
if($user_id) {
    $activity_log = new ActivityLog($db);
    $activity_log->id = uniqid();
    $activity_log->user_id = $user_id;
    $activity_log->activity_type = "read";
    $activity_log->entity_type = "Analytics";
    $activity_log->entity_id = "stock_movement";
    $activity_log->description = "Viewed stock movement analytics";
    $activity_log->create();
}

// Determine date range based on time range parameter
$endDate = date('Y-m-d');
$startDate = '';

switch($timeRange) {
    case 'Last 7 Days':
        $startDate = date('Y-m-d', strtotime('-7 days'));
        break;
    case 'Last 30 Days':
        $startDate = date('Y-m-d', strtotime('-30 days'));
        break;
    case 'Last 3 Months':
        $startDate = date('Y-m-d', strtotime('-3 months'));
        break;
    case 'Last Year':
        $startDate = date('Y-m-d', strtotime('-1 year'));
        break;
    default:
        $startDate = date('Y-m-d', strtotime('-7 days'));
}

// Build query
$query = "SELECT 
            DATE_FORMAT(t.timestamp, '%Y-%m-%d') as date,
            SUM(CASE WHEN t.type = 'stock_in' THEN t.quantity ELSE 0 END) as stock_in,
            SUM(CASE WHEN t.type = 'stock_out' THEN t.quantity ELSE 0 END) as stock_out
          FROM 
            transactions t
            JOIN products p ON t.product_id = p.id
            JOIN warehouses w ON t.warehouse_id = w.id
          WHERE 
            t.timestamp BETWEEN :startDate AND :endDate";

// Add filters if provided
if($warehouse && $warehouse != 'All Warehouses') {
    $query .= " AND w.name = :warehouse";
}

if($category && $category != 'All Categories') {
    $query .= " AND p.category_id IN (SELECT id FROM categories WHERE name = :category)";
}

$query .= " GROUP BY DATE_FORMAT(t.timestamp, '%Y-%m-%d')
            ORDER BY date ASC";

// Prepare statement
$stmt = $db->prepare($query);

// Bind parameters
$stmt->bindParam(':startDate', $startDate);
$stmt->bindParam(':endDate', $endDate);

if($warehouse && $warehouse != 'All Warehouses') {
    $stmt->bindParam(':warehouse', $warehouse);
}

if($category && $category != 'All Categories') {
    $stmt->bindParam(':category', $category);
}

// Execute query
$stmt->execute();

// Check if data exists
if($stmt->rowCount() > 0) {
    // Data array
    $data_arr = array();
    $data_arr["records"] = array();
    
    // Fetch all data
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        
        $data_item = array(
            "date" => $date,
            "stockIn" => (int)$stock_in,
            "stockOut" => (int)$stock_out
        );
        
        array_push($data_arr["records"], $data_item);
    }
    
    // Set response code - 200 OK
    http_response_code(200);
    
    // Return data
    echo json_encode($data_arr);
} else {
    // Set response code - 404 Not found
    http_response_code(404);
    
    // No data found
    echo json_encode(array("message" => "No stock movement data found."));
}
?>