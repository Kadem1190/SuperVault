<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include database and models
include_once '../config/database.php';
include_once '../models/warehouse.php';
include_once '../models/activity_log.php';

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Instantiate warehouse object
$warehouse = new Warehouse($db);

// Get posted data
$data = json_decode(file_get_contents("php://input"));

// Make sure id is not empty and user_id is provided
if(!empty($data->id) && !empty($data->user_id)) {
    // Set warehouse property values
    $warehouse->id = $data->id;
    $warehouse->name = $data->name;
    $warehouse->address = $data->address;
    $warehouse->contact_person = $data->contact_person;
    $warehouse->contact_phone = $data->contact_phone;
    $warehouse->capacity = $data->capacity;
    $warehouse->image_url = $data->image_url;
    
    // Update the warehouse
    if($warehouse->update()) {
        // Log the activity
        $activity_log = new ActivityLog($db);
        $activity_log->id = uniqid();
        $activity_log->user_id = $data->user_id;
        $activity_log->activity_type = "update";
        $activity_log->entity_type = "Warehouse";
        $activity_log->entity_id = $warehouse->id;
        $activity_log->description = "Updated warehouse: {$warehouse->name}";
        $activity_log->create();
        
        // Set response code - 200 ok
        http_response_code(200);
        
        // Tell the user
        echo json_encode(array("message" => "Warehouse was updated."));
    } else {
        // Set response code - 503 service unavailable
        http_response_code(503);
        
        // Tell the user
        echo json_encode(array("message" => "Unable to update warehouse."));
    }
} else {
    // Set response code - 400 bad request
    http_response_code(400);
    
    // Tell the user
    echo json_encode(array("message" => "Unable to update warehouse. Data is incomplete."));
}
?>