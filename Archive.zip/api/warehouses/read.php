<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Include database and warehouse model
include_once '../config/database.php';
include_once '../models/warehouse.php';
include_once '../models/activity_log.php';

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Instantiate warehouse object
$warehouse = new Warehouse($db);

// Get query parameters
$search = isset($_GET['search']) ? $_GET['search'] : null;
$user_id = isset($_GET['user_id']) ? $_GET['user_id'] : null;

// Query warehouses
$stmt = $warehouse->read($search);
$num = $stmt->rowCount();

// Log the activity if user_id is provided
if($user_id) {
    $activity_log = new ActivityLog($db);
    $activity_log->id = uniqid();
    $activity_log->user_id = $user_id;
    $activity_log->activity_type = "read";
    $activity_log->entity_type = "Warehouse";
    $activity_log->entity_id = "all";
    $activity_log->description = "Viewed warehouse list";
    $activity_log->create();
}

// Check if more than 0 record found
if($num > 0) {
    // Warehouses array
    $warehouses_arr = array();
    $warehouses_arr["records"] = array();
    
    // Retrieve table contents
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        
        $warehouse_item = array(
            "id" => $id,
            "name" => $name,
            "address" => $address,
            "contact_person" => $contact_person,
            "contact_phone" => $contact_phone,
            "capacity" => $capacity,
            "image_url" => $image_url,
            "created_at" => $created_at,
            "updated_at" => $updated_at
        );
        
        array_push($warehouses_arr["records"], $warehouse_item);
    }
    
    // Set response code - 200 OK
    http_response_code(200);
    
    // Show warehouses data in json format
    echo json_encode($warehouses_arr);
} else {
    // Set response code - 404 Not found
    http_response_code(404);
    
    // Tell the user no warehouses found
    echo json_encode(array("message" => "No warehouses found."));
}
?>