<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include database and models
include_once '../config/database.php';
include_once '../models/warehouse.php';
include_once '../models/activity_log.php';

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Instantiate warehouse object
$warehouse = new Warehouse($db);

// Get posted data
$data = json_decode(file_get_contents("php://input"));

// Make sure data is not empty
if(
    !empty($data->name) &&
    !empty($data->address) &&
    !empty($data->contact_person) &&
    !empty($data->contact_phone) &&
    !empty($data->capacity) &&
    !empty($data->user_id)
) {
    // Set warehouse property values
    $warehouse->id = uniqid();
    $warehouse->name = $data->name;
    $warehouse->address = $data->address;
    $warehouse->contact_person = $data->contact_person;
    $warehouse->contact_phone = $data->contact_phone;
    $warehouse->capacity = $data->capacity;
    $warehouse->image_url = $data->image_url ?? null;
    
    // Create the warehouse
    if($warehouse->create()) {
        // Log the activity
        $activity_log = new ActivityLog($db);
        $activity_log->id = uniqid();
        $activity_log->user_id = $data->user_id;
        $activity_log->activity_type = "create";
        $activity_log->entity_type = "Warehouse";
        $activity_log->entity_id = $warehouse->id;
        $activity_log->description = "Created new warehouse: {$warehouse->name}";
        $activity_log->create();
        
        // Set response code - 201 created
        http_response_code(201);
        
        // Tell the user
        echo json_encode(array(
            "message" => "Warehouse was created.",
            "id" => $warehouse->id
        ));
    } else {
        // Set response code - 503 service unavailable
        http_response_code(503);
        
        // Tell the user
        echo json_encode(array("message" => "Unable to create warehouse."));
    }
} else {
    // Set response code - 400 bad request
    http_response_code(400);
    
    // Tell the user
    echo json_encode(array("message" => "Unable to create warehouse. Data is incomplete."));
}
?>