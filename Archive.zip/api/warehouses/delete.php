<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include database and models
include_once '../config/database.php';
include_once '../models/warehouse.php';
include_once '../models/activity_log.php';

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Instantiate warehouse object
$warehouse = new Warehouse($db);

// Get warehouse id and user id
$data = json_decode(file_get_contents("php://input"));

// Make sure ids are not empty
if(!empty($data->id) && !empty($data->user_id)) {
    // Set warehouse id to be deleted
    $warehouse->id = $data->id;
    
    // Get warehouse details before deletion for logging
    $warehouse->readOne();
    $warehouse_name = $warehouse->name;
    
    // Delete the warehouse
    if($warehouse->delete()) {
        // Log the activity
        $activity_log = new ActivityLog($db);
        $activity_log->id = uniqid();
        $activity_log->user_id = $data->user_id;
        $activity_log->activity_type = "delete";
        $activity_log->entity_type = "Warehouse";
        $activity_log->entity_id = $warehouse->id;
        $activity_log->description = "Deleted warehouse: {$warehouse_name}";
        $activity_log->create();
        
        // Set response code - 200 ok
        http_response_code(200);
        
        // Tell the user
        echo json_encode(array("message" => "Warehouse was deleted."));
    } else {
        // Set response code - 503 service unavailable
        http_response_code(503);
        
        // Tell the user
        echo json_encode(array("message" => "Unable to delete warehouse."));
    }
} else {
    // Set response code - 400 bad request
    http_response_code(400);
    
    // Tell the user
    echo json_encode(array("message" => "Unable to delete warehouse. Warehouse ID or User ID is missing."));
}
?>