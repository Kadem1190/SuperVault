<?php
class Transaction {
    // Database connection and table name
    private $conn;
    private $table_name = "transactions";
    
    // Object properties
    public $id;
    public $product_id;
    public $warehouse_id;
    public $destination_warehouse_id;
    public $user_id;
    public $type;
    public $quantity;
    public $notes;
    public $timestamp;
    
    // Constructor with DB
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Read transactions
    function read($type = null, $warehouse = null, $search = null) {
        // Select all query
        $query = "SELECT
                    t.id, t.product_id, t.warehouse_id, t.destination_warehouse_id, t.user_id, t.type, t.quantity, t.notes, t.timestamp,
                    p.name as product_name, p.sku,
                    w1.name as warehouse_name,
                    w2.name as destination_warehouse_name,
                    u.name as user_name
                FROM
                    " . $this->table_name . " t
                    LEFT JOIN
                        products p ON t.product_id = p.id
                    LEFT JOIN
                        warehouses w1 ON t.warehouse_id = w1.id
                    LEFT JOIN
                        warehouses w2 ON t.destination_warehouse_id = w2.id
                    LEFT JOIN
                        users u ON t.user_id = u.id
                WHERE 1=1";
        
        // Filter by type if provided
        if($type && $type != 'All Types') {
            $query .= " AND t.type = :type";
        }
        
        // Filter by warehouse if provided
        if($warehouse && $warehouse != 'All Warehouses') {
            $query .= " AND (w1.name = :warehouse OR w2.name = :warehouse)";
        }
        
        // Filter by search term if provided
        if($search) {
            $query .= " AND (p.name LIKE :search OR p.sku LIKE :search OR u.name LIKE :search)";
        }
        
        $query .= " ORDER BY t.timestamp DESC";
        
        // Prepare query statement
        $stmt = $this->conn->prepare($query);
        
        // Bind values
        if($type && $type != 'All Types') {
            $type_value = strtolower(str_replace(' ', '_', $type));
            $stmt->bindParam(":type", $type_value);
        }
        
        if($warehouse && $warehouse != 'All Warehouses') {
            $stmt->bindParam(":warehouse", $warehouse);
        }
        
        if($search) {
            $search = "%{$search}%";
            $stmt->bindParam(":search", $search);
        }
        
        // Execute query
        $stmt->execute();
        
        return $stmt;
    }
    
    // Create transaction
    function create() {
        // Query to insert record
        $query = "INSERT INTO " . $this->table_name . "
                SET
                    id=:id,
                    product_id=:product_id,
                    warehouse_id=:warehouse_id,
                    destination_warehouse_id=:destination_warehouse_id,
                    user_id=:user_id,
                    type=:type,
                    quantity=:quantity,
                    notes=:notes";
        
        // Prepare query
        $stmt = $this->conn->prepare($query);
        
        // Sanitize
        $this->id = htmlspecialchars(strip_tags($this->id));
        $this->product_id = htmlspecialchars(strip_tags($this->product_id));
        $this->warehouse_id = htmlspecialchars(strip_tags($this->warehouse_id));
        $this->user_id = htmlspecialchars(strip_tags($this->user_id));
        $this->type = htmlspecialchars(strip_tags($this->type));
        $this->quantity = htmlspecialchars(strip_tags($this->quantity));
        $this->notes = htmlspecialchars(strip_tags($this->notes));
        
        // Bind values
        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":product_id", $this->product_id);
        $stmt->bindParam(":warehouse_id", $this->warehouse_id);
        $stmt->bindParam(":destination_warehouse_id", $this->destination_warehouse_id);
        $stmt->bindParam(":user_id", $this->user_id);
        $stmt->bindParam(":type", $this->type);
        $stmt->bindParam(":quantity", $this->quantity);
        $stmt->bindParam(":notes", $this->notes);
        
        // Execute query
        if($stmt->execute()) {
            return true;
        }
        
        return false;
    }
}
?>