<?php
class User {
    // Database connection and table name
    private $conn;
    private $table_name = "users";
    
    // Object properties
    public $id;
    public $name;
    public $email;
    public $password;
    public $role;
    public $avatar_url;
    public $created_at;
    public $updated_at;
    
    // Constructor with DB
    public function __construct($db) {
        $this->conn = $db;
    }
    
// Login user
function login($password) {
    // Query to read single record
    $query = "SELECT id, name, email, password, role, avatar_url 
            FROM " . $this->table_name . " 
            WHERE email = ?
            LIMIT 0,1";
    
    // Prepare query statement
    $stmt = $this->conn->prepare($query);
    
    // Bind email value
    $stmt->bindParam(1, $this->email);
    
    // Execute query
    $stmt->execute();
    
    // Get retrieved row
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // If row exists
    if($row) {
        // Set values to object properties
        $this->id = $row['id'];
        $this->name = $row['name'];
        $this->email = $row['email'];
        $this->role = $row['role'];
        $this->avatar_url = $row['avatar_url'];
        $hashed_password = $row['password'];
        
        // Verify password using PHP's password_verify function
        if(password_verify($password, $hashed_password)) {
            return true;
        }
    }
    
    return false;
}
    
    // Get user by ID
    function readOne() {
        // Query to read single record
        $query = "SELECT id, name, email, role, avatar_url, created_at, updated_at 
                FROM " . $this->table_name . " 
                WHERE id = ?
                LIMIT 0,1";
        
        // Prepare query statement
        $stmt = $this->conn->prepare($query);
        
        // Bind ID
        $stmt->bindParam(1, $this->id);
        
        // Execute query
        $stmt->execute();
        
        // Get retrieved row
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Set values to object properties
        if($row) {
            $this->name = $row['name'];
            $this->email = $row['email'];
            $this->role = $row['role'];
            $this->avatar_url = $row['avatar_url'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            return true;
        }
        
        return false;
    }
    
    // Update user profile
    function update() {
        // Update query
        $query = "UPDATE " . $this->table_name . "
                SET
                    name = :name,
                    email = :email
                WHERE
                    id = :id";
        
        // Prepare query statement
        $stmt = $this->conn->prepare($query);
        
        // Sanitize
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->id = htmlspecialchars(strip_tags($this->id));
        
        // Bind values
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":id", $this->id);
        
        // Execute query
        if($stmt->execute()) {
            return true;
        }
        
        return false;
    }
}
?>