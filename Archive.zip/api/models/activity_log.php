<?php
class ActivityLog {
    // Database connection and table name
    private $conn;
    private $table_name = "activity_logs";
    
    // Object properties
    public $id;
    public $user_id;
    public $activity_type;
    public $entity_type;
    public $entity_id;
    public $description;
    public $timestamp;
    
    // Constructor with DB
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create activity log
    function create() {
        // Query to insert record
        $query = "INSERT INTO " . $this->table_name . "
                SET
                    id=:id,
                    user_id=:user_id,
                    activity_type=:activity_type,
                    entity_type=:entity_type,
                    entity_id=:entity_id,
                    description=:description";
        
        // Prepare query
        $stmt = $this->conn->prepare($query);
        
        // Sanitize
        $this->id = htmlspecialchars(strip_tags($this->id));
        $this->user_id = htmlspecialchars(strip_tags($this->user_id));
        $this->activity_type = htmlspecialchars(strip_tags($this->activity_type));
        $this->entity_type = htmlspecialchars(strip_tags($this->entity_type));
        $this->entity_id = htmlspecialchars(strip_tags($this->entity_id));
        $this->description = htmlspecialchars(strip_tags($this->description));
        
        // Bind values
        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":user_id", $this->user_id);
        $stmt->bindParam(":activity_type", $this->activity_type);
        $stmt->bindParam(":entity_type", $this->entity_type);
        $stmt->bindParam(":entity_id", $this->entity_id);
        $stmt->bindParam(":description", $this->description);
        
        // Execute query
        if($stmt->execute()) {
            return true;
        }
        
        return false;
    }
    
    // Read activity logs
    function read($activity = null, $user = null, $search = null) {
        // Select all query
        $query = "SELECT
                    a.id, a.user_id, a.activity_type, a.entity_type, a.entity_id, a.description, a.timestamp,
                    u.name as user_name, u.role as user_role,
                    CASE 
                        WHEN a.entity_type = 'Product' THEN p.name
                        WHEN a.entity_type = 'Warehouse' THEN w.name
                        ELSE a.entity_id
                    END as entity_name
                FROM
                    " . $this->table_name . " a
                    LEFT JOIN
                        users u ON a.user_id = u.id
                    LEFT JOIN
                        products p ON a.entity_type = 'Product' AND a.entity_id = p.id
                    LEFT JOIN
                        warehouses w ON a.entity_type = 'Warehouse' AND a.entity_id = w.id
                WHERE 1=1";
        
        // Filter by activity type if provided
        if($activity && $activity != 'All Activities') {
            $query .= " AND a.activity_type = :activity";
        }
        
        // Filter by user if provided
        if($user && $user != 'All Users') {
            $query .= " AND u.name = :user";
        }
        
        // Filter by search term if provided
        if($search) {
            $query .= " AND (a.description LIKE :search OR a.entity_type LIKE :search)";
        }
        
        $query .= " ORDER BY a.timestamp DESC";
        
        // Prepare query statement
        $stmt = $this->conn->prepare($query);
        
        // Bind values
        if($activity && $activity != 'All Activities') {
            $activity_value = strtolower($activity);
            $stmt->bindParam(":activity", $activity_value);
        }
        
        if($user && $user != 'All Users') {
            $stmt->bindParam(":user", $user);
        }
        
        if($search) {
            $search = "%{$search}%";
            $stmt->bindParam(":search", $search);
        }
        
        // Execute query
        $stmt->execute();
        
        return $stmt;
    }
}
?>