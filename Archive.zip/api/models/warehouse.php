<?php
class Warehouse {
    // Database connection and table name
    private $conn;
    private $table_name = "warehouses";
    
    // Object properties
    public $id;
    public $name;
    public $address;
    public $contact_person;
    public $contact_phone;
    public $capacity;
    public $image_url;
    public $created_at;
    public $updated_at;
    
    // Constructor with DB
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Read warehouses
    function read($search = null) {
        // Select all query
        $query = "SELECT
                    id, name, address, contact_person, contact_phone, capacity, image_url, created_at, updated_at
                FROM
                    " . $this->table_name . "
                WHERE 1=1";
        
        // Filter by search term if provided
        if($search) {
            $query .= " AND (name LIKE :search OR address LIKE :search OR contact_person LIKE :search)";
        }
        
        $query .= " ORDER BY name ASC";
        
        // Prepare query statement
        $stmt = $this->conn->prepare($query);
        
        // Bind values
        if($search) {
            $search = "%{$search}%";
            $stmt->bindParam(":search", $search);
        }
        
        // Execute query
        $stmt->execute();
        
        return $stmt;
    }
    
    // Read one warehouse
    function readOne() {
        // Query to read single record
        $query = "SELECT
                    id, name, address, contact_person, contact_phone, capacity, image_url, created_at, updated_at
                FROM
                    " . $this->table_name . "
                WHERE
                    id = ?
                LIMIT 0,1";
        
        // Prepare query statement
        $stmt = $this->conn->prepare($query);
        
        // Bind id of warehouse to be updated
        $stmt->bindParam(1, $this->id);
        
        // Execute query
        $stmt->execute();
        
        // Get retrieved row
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Set values to object properties
        if($row) {
            $this->name = $row['name'];
            $this->address = $row['address'];
            $this->contact_person = $row['contact_person'];
            $this->contact_phone = $row['contact_phone'];
            $this->capacity = $row['capacity'];
            $this->image_url = $row['image_url'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            return true;
        }
        
        return false;
    }
    
    // Create warehouse
    function create() {
        // Query to insert record
        $query = "INSERT INTO " . $this->table_name . "
                SET
                    id=:id,
                    name=:name,
                    address=:address,
                    contact_person=:contact_person,
                    contact_phone=:contact_phone,
                    capacity=:capacity,
                    image_url=:image_url";
        
        // Prepare query
        $stmt = $this->conn->prepare($query);
        
        // Sanitize
        $this->id = htmlspecialchars(strip_tags($this->id));
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->address = htmlspecialchars(strip_tags($this->address));
        $this->contact_person = htmlspecialchars(strip_tags($this->contact_person));
        $this->contact_phone = htmlspecialchars(strip_tags($this->contact_phone));
        $this->capacity = htmlspecialchars(strip_tags($this->capacity));
        $this->image_url = htmlspecialchars(strip_tags($this->image_url));
        
        // Bind values
        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":address", $this->address);
        $stmt->bindParam(":contact_person", $this->contact_person);
        $stmt->bindParam(":contact_phone", $this->contact_phone);
        $stmt->bindParam(":capacity", $this->capacity);
        $stmt->bindParam(":image_url", $this->image_url);
        
        // Execute query
        if($stmt->execute()) {
            return true;
        }
        
        return false;
    }
    
    // Update warehouse
    function update() {
        // Update query
        $query = "UPDATE " . $this->table_name . "
                SET
                    name = :name,
                    address = :address,
                    contact_person = :contact_person,
                    contact_phone = :contact_phone,
                    capacity = :capacity,
                    image_url = :image_url
                WHERE
                    id = :id";
        
        // Prepare query statement
        $stmt = $this->conn->prepare($query);
        
        // Sanitize
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->address = htmlspecialchars(strip_tags($this->address));
        $this->contact_person = htmlspecialchars(strip_tags($this->contact_person));
        $this->contact_phone = htmlspecialchars(strip_tags($this->contact_phone));
        $this->capacity = htmlspecialchars(strip_tags($this->capacity));
        $this->image_url = htmlspecialchars(strip_tags($this->image_url));
        $this->id = htmlspecialchars(strip_tags($this->id));
        
        // Bind values
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":address", $this->address);
        $stmt->bindParam(":contact_person", $this->contact_person);
        $stmt->bindParam(":contact_phone", $this->contact_phone);
        $stmt->bindParam(":capacity", $this->capacity);
        $stmt->bindParam(":image_url", $this->image_url);
        $stmt->bindParam(":id", $this->id);
        
        // Execute query
        if($stmt->execute()) {
            return true;
        }
        
        return false;
    }
    
    // Delete warehouse
    function delete() {
        // Delete query
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
        
        // Prepare query
        $stmt = $this->conn->prepare($query);
        
        // Sanitize
        $this->id = htmlspecialchars(strip_tags($this->id));
        
        // Bind id of record to delete
        $stmt->bindParam(1, $this->id);
        
        // Execute query
        if($stmt->execute()) {
            return true;
        }
        
        return false;
    }
}
?>