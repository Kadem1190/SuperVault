<?php
class Inventory {
    // Database connection and table name
    private $conn;
    private $table_name = "inventory";
    
    // Object properties
    public $id;
    public $product_id;
    public $warehouse_id;
    public $quantity;
    public $location;
    public $last_updated;
    
    // Constructor with DB
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Read inventory
    function read($warehouse = null, $category = null, $search = null) {
        // Select all query
        $query = "SELECT
                    i.id, i.product_id, i.warehouse_id, i.quantity, i.location, i.last_updated,
                    p.name as product_name, p.sku, p.category_id,
                    c.name as category_name,
                    w.name as warehouse_name
                FROM
                    " . $this->table_name . " i
                    LEFT JOIN
                        products p ON i.product_id = p.id
                    LEFT JOIN
                        categories c ON p.category_id = c.id
                    LEFT JOIN
                        warehouses w ON i.warehouse_id = w.id
                WHERE 1=1";
        
        // Filter by warehouse if provided
        if($warehouse && $warehouse != 'All Warehouses') {
            $query .= " AND w.name = :warehouse";
        }
        
        // Filter by category if provided
        if($category && $category != 'All Categories') {
            $query .= " AND c.name = :category";
        }
        
        // Filter by search term if provided
        if($search) {
            $query .= " AND (p.name LIKE :search OR p.sku LIKE :search)";
        }
        
        $query .= " ORDER BY i.last_updated DESC";
        
        // Prepare query statement
        $stmt = $this->conn->prepare($query);
        
        // Bind values
        if($warehouse && $warehouse != 'All Warehouses') {
            $stmt->bindParam(":warehouse", $warehouse);
        }
        
        if($category && $category != 'All Categories') {
            $stmt->bindParam(":category", $category);
        }
        
        if($search) {
            $search = "%{$search}%";
            $stmt->bindParam(":search", $search);
        }
        
        // Execute query
        $stmt->execute();
        
        return $stmt;
    }
    
    // Read one inventory item
    function readOne() {
        // Query to read single record
        $query = "SELECT
                    i.id, i.product_id, i.warehouse_id, i.quantity, i.location, i.last_updated,
                    p.name as product_name, p.sku,
                    w.name as warehouse_name
                FROM
                    " . $this->table_name . " i
                    LEFT JOIN
                        products p ON i.product_id = p.id
                    LEFT JOIN
                        warehouses w ON i.warehouse_id = w.id
                WHERE
                    i.id = ?
                LIMIT 0,1";
        
        // Prepare query statement
        $stmt = $this->conn->prepare($query);
        
        // Bind id of inventory to be updated
        $stmt->bindParam(1, $this->id);
        
        // Execute query
        $stmt->execute();
        
        // Get retrieved row
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Set values to object properties
        if($row) {
            $this->product_id = $row['product_id'];
            $this->warehouse_id = $row['warehouse_id'];
            $this->quantity = $row['quantity'];
            $this->location = $row['location'];
            $this->last_updated = $row['last_updated'];
            return true;
        }
        
        return false;
    }
    
    // Update inventory quantity
    function update() {
        // Update query
        $query = "UPDATE " . $this->table_name . "
                SET
                    quantity = :quantity,
                    location = :location
                WHERE
                    id = :id";
        
        // Prepare query statement
        $stmt = $this->conn->prepare($query);
        
        // Sanitize
        $this->quantity = htmlspecialchars(strip_tags($this->quantity));
        $this->location = htmlspecialchars(strip_tags($this->location));
        $this->id = htmlspecialchars(strip_tags($this->id));
        
        // Bind values
        $stmt->bindParam(":quantity", $this->quantity);
        $stmt->bindParam(":location", $this->location);
        $stmt->bindParam(":id", $this->id);
        
        // Execute query
        if($stmt->execute()) {
            return true;
        }
        
        return false;
    }
    
    // Create inventory item
    function create() {
        // Query to insert record
        $query = "INSERT INTO " . $this->table_name . "
                SET
                    id=:id,
                    product_id=:product_id,
                    warehouse_id=:warehouse_id,
                    quantity=:quantity,
                    location=:location";
        
        // Prepare query
        $stmt = $this->conn->prepare($query);
        
        // Sanitize
        $this->id = htmlspecialchars(strip_tags($this->id));
        $this->product_id = htmlspecialchars(strip_tags($this->product_id));
        $this->warehouse_id = htmlspecialchars(strip_tags($this->warehouse_id));
        $this->quantity = htmlspecialchars(strip_tags($this->quantity));
        $this->location = htmlspecialchars(strip_tags($this->location));
        
        // Bind values
        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":product_id", $this->product_id);
        $stmt->bindParam(":warehouse_id", $this->warehouse_id);
        $stmt->bindParam(":quantity", $this->quantity);
        $stmt->bindParam(":location", $this->location);
        
        // Execute query
        if($stmt->execute()) {
            return true;
        }
        
        return false;
    }
}
?>