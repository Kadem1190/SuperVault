<?php
class Product {
    // Database connection and table name
    private $conn;
    private $table_name = "products";
    
    // Object properties
    public $id;
    public $name;
    public $sku;
    public $description;
    public $category_id;
    public $price;
    public $image_url;
    public $created_at;
    public $updated_at;
    
    // Constructor with DB
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Read products
    function read($category = null, $search = null) {
        // Select all query
        $query = "SELECT
                    p.id, p.name, p.sku, p.description, p.category_id, p.price, p.image_url, p.created_at, p.updated_at,
                    c.name as category_name
                FROM
                    " . $this->table_name . " p
                    LEFT JOIN
                        categories c ON p.category_id = c.id
                WHERE 1=1";
        
        // Filter by category if provided
        if($category && $category != 'All Categories') {
            $query .= " AND c.name = :category";
        }
        
        // Filter by search term if provided
        if($search) {
            $query .= " AND (p.name LIKE :search OR p.sku LIKE :search)";
        }
        
        $query .= " ORDER BY p.created_at DESC";
        
        // Prepare query statement
        $stmt = $this->conn->prepare($query);
        
        // Bind values
        if($category && $category != 'All Categories') {
            $stmt->bindParam(":category", $category);
        }
        
        if($search) {
            $search = "%{$search}%";
            $stmt->bindParam(":search", $search);
        }
        
        // Execute query
        $stmt->execute();
        
        return $stmt;
    }
    
    // Create product
    function create() {
        // Query to insert record
        $query = "INSERT INTO " . $this->table_name . "
                SET
                    id=:id,
                    name=:name,
                    sku=:sku,
                    description=:description,
                    category_id=:category_id,
                    price=:price,
                    image_url=:image_url";
        
        // Prepare query
        $stmt = $this->conn->prepare($query);
        
        // Sanitize
        $this->id = htmlspecialchars(strip_tags($this->id));
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->sku = htmlspecialchars(strip_tags($this->sku));
        $this->description = htmlspecialchars(strip_tags($this->description));
        $this->category_id = htmlspecialchars(strip_tags($this->category_id));
        $this->price = htmlspecialchars(strip_tags($this->price));
        $this->image_url = htmlspecialchars(strip_tags($this->image_url));
        
        // Bind values
        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":sku", $this->sku);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":category_id", $this->category_id);
        $stmt->bindParam(":price", $this->price);
        $stmt->bindParam(":image_url", $this->image_url);
        
        // Execute query
        if($stmt->execute()) {
            return true;
        }
        
        return false;
    }
    
    // Read one product
    function readOne() {
        // Query to read single record
        $query = "SELECT
                    p.id, p.name, p.sku, p.description, p.category_id, p.price, p.image_url, p.created_at, p.updated_at,
                    c.name as category_name
                FROM
                    " . $this->table_name . " p
                    LEFT JOIN
                        categories c ON p.category_id = c.id
                WHERE
                    p.id = ?
                LIMIT 0,1";
        
        // Prepare query statement
        $stmt = $this->conn->prepare($query);
        
        // Bind id of product to be updated
        $stmt->bindParam(1, $this->id);
        
        // Execute query
        $stmt->execute();
        
        // Get retrieved row
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Set values to object properties
        if($row) {
            $this->name = $row['name'];
            $this->sku = $row['sku'];
            $this->description = $row['description'];
            $this->category_id = $row['category_id'];
            $this->price = $row['price'];
            $this->image_url = $row['image_url'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            return true;
        }
        
        return false;
    }
    
    // Update product
    function update() {
        // Update query
        $query = "UPDATE " . $this->table_name . "
                SET
                    name = :name,
                    sku = :sku,
                    description = :description,
                    category_id = :category_id,
                    price = :price,
                    image_url = :image_url
                WHERE
                    id = :id";
        
        // Prepare query statement
        $stmt = $this->conn->prepare($query);
        
        // Sanitize
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->sku = htmlspecialchars(strip_tags($this->sku));
        $this->description = htmlspecialchars(strip_tags($this->description));
        $this->category_id = htmlspecialchars(strip_tags($this->category_id));
        $this->price = htmlspecialchars(strip_tags($this->price));
        $this->image_url = htmlspecialchars(strip_tags($this->image_url));
        $this->id = htmlspecialchars(strip_tags($this->id));
        
        // Bind values
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":sku", $this->sku);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":category_id", $this->category_id);
        $stmt->bindParam(":price", $this->price);
        $stmt->bindParam(":image_url", $this->image_url);
        $stmt->bindParam(":id", $this->id);
        
        // Execute query
        if($stmt->execute()) {
            return true;
        }
        
        return false;
    }
    
    // Delete product
    function delete() {
        // Delete query
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
        
        // Prepare query
        $stmt = $this->conn->prepare($query);
        
        // Sanitize
        $this->id = htmlspecialchars(strip_tags($this->id));
        
        // Bind id of record to delete
        $stmt->bindParam(1, $this->id);
        
        // Execute query
        if($stmt->execute()) {
            return true;
        }
        
        return false;
    }
}
?>