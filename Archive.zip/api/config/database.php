<?php
class Database {
    private $host = "bvtxenddold3lzwdukjy-mysql.services.clever-cloud.com";
    private $db_name = "bvtxenddold3lzwdukjy";
    private $username = "unvyy3uh7msusboi";
    private $password = "tAIocclPPR45NTeXgA5R";
    private $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->exec("set names utf8");
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $exception) {
            // Log the error for debugging
            error_log("Connection error: " . $exception->getMessage());
            echo "Connection error: " . $exception->getMessage();
        }
        return $this->conn;
    }
}
?>