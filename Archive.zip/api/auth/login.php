<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include database and user model
include_once '../config/database.php';
include_once '../models/user.php';
include_once '../models/activity_log.php';

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Check if database connection was successful
if(!$db) {
    // Set response code - 500 internal server error
    http_response_code(500);
    
    // Tell the user
    echo json_encode(array("message" => "Database connection failed."));
    exit;
}

// Instantiate user object
$user = new User($db);

// Get posted data
$data = json_decode(file_get_contents("php://input"));

// Debug log
error_log("Login attempt: " . json_encode($data));

// Make sure data is not empty
if(!empty($data->email) && !empty($data->password)) {
    
    // Set user property values
    $user->email = $data->email;
    $passwordInput = $data->password;
    
    // Debug log
    error_log("Checking user: " . $user->email);
    
    // Check if user exists in database
    $query = "SELECT email FROM users WHERE email = ?";
    $stmt = $db->prepare($query);
    $stmt->bindParam(1, $user->email);
    $stmt->execute();
    
    if($stmt->rowCount() > 0) {
        error_log("User found in database");
    } else {
        error_log("User not found in database");
    }
    
    // Check if user exists and password is correct
    if($user->login($passwordInput)) {
        // Create array
        $user_arr = array(
            "id" => $user->id,
            "name" => $user->name,
            "email" => $user->email,
            "role" => $user->role,
            "avatar_url" => $user->avatar_url
        );
        
        // Debug log
        error_log("Login successful for: " . $user->email);
        
        // Log the login activity
        $activity_log = new ActivityLog($db);
        $activity_log->id = uniqid();
        $activity_log->user_id = $user->id;
        $activity_log->activity_type = "read";
        $activity_log->entity_type = "User";
        $activity_log->entity_id = $user->id;
        $activity_log->description = "User logged in: " . $user->name;
        $activity_log->create();
        
        // Set response code - 200 OK
        http_response_code(200);
        
        // Make it json format
        echo json_encode($user_arr);
    } else {
        // Debug log
        error_log("Login failed for: " . $user->email);
        
        // Get the stored password for debugging
        $query = "SELECT password FROM users WHERE email = ?";
        $stmt = $db->prepare($query);
        $stmt->bindParam(1, $user->email);
        $stmt->execute();
        
        if($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            error_log("Stored password hash: " . $row['password']);
        }
        
        // Set response code - 401 Unauthorized
        http_response_code(401);
        
        // Tell the user login failed
        echo json_encode(array("message" => "Invalid email or password."));
    }
} else {
    // Debug log
    error_log("Login attempt with incomplete data");
    
    // Set response code - 400 bad request
    http_response_code(400);
    
    // Tell the user data is incomplete
    echo json_encode(array("message" => "Unable to login. Data is incomplete."));
}
?>