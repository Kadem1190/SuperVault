<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include database and models
include_once '../config/database.php';
include_once '../models/product.php';
include_once '../models/activity_log.php';

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Instantiate product object
$product = new Product($db);

// Get posted data
$data = json_decode(file_get_contents("php://input"));

// Make sure id is not empty and user_id is provided
if(!empty($data->id) && !empty($data->user_id)) {
    // Set product property values
    $product->id = $data->id;
    $product->name = $data->name;
    $product->sku = $data->sku;
    $product->description = $data->description;
    $product->category_id = $data->category_id;
    $product->price = $data->price;
    $product->image_url = $data->image_url;
    
    // Update the product
    if($product->update()) {
        // Log the activity
        $activity_log = new ActivityLog($db);
        $activity_log->id = uniqid();
        $activity_log->user_id = $data->user_id;
        $activity_log->activity_type = "update";
        $activity_log->entity_type = "Product";
        $activity_log->entity_id = $product->id;
        $activity_log->description = "Updated product: {$product->name} ({$product->sku})";
        $activity_log->create();
        
        // Set response code - 200 ok
        http_response_code(200);
        
        // Tell the user
        echo json_encode(array("message" => "Product was updated."));
    } else {
        // Set response code - 503 service unavailable
        http_response_code(503);
        
        // Tell the user
        echo json_encode(array("message" => "Unable to update product."));
    }
} else {
    // Set response code - 400 bad request
    http_response_code(400);
    
    // Tell the user
    echo json_encode(array("message" => "Unable to update product. Data is incomplete."));
}
?>