<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include database and models
include_once '../config/database.php';
include_once '../models/product.php';
include_once '../models/activity_log.php';

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Instantiate product object
$product = new Product($db);

// Get posted data
$data = json_decode(file_get_contents("php://input"));

// Make sure data is not empty
if(
    !empty($data->name) &&
    !empty($data->sku) &&
    !empty($data->category_id) &&
    !empty($data->price) &&
    !empty($data->user_id)
) {
    // Set product property values
    $product->id = uniqid();
    $product->name = $data->name;
    $product->sku = $data->sku;
    $product->description = $data->description ?? "";
    $product->category_id = $data->category_id;
    $product->price = $data->price;
    $product->image_url = $data->image_url ?? null;
    
    // Create the product
    if($product->create()) {
        // Log the activity
        $activity_log = new ActivityLog($db);
        $activity_log->id = uniqid();
        $activity_log->user_id = $data->user_id;
        $activity_log->activity_type = "create";
        $activity_log->entity_type = "Product";
        $activity_log->entity_id = $product->id;
        $activity_log->description = "Created new product: {$product->name} ({$product->sku})";
        $activity_log->create();
        
        // Set response code - 201 created
        http_response_code(201);
        
        // Tell the user
        echo json_encode(array(
            "message" => "Product was created.",
            "id" => $product->id
        ));
    } else {
        // Set response code - 503 service unavailable
        http_response_code(503);
        
        // Tell the user
        echo json_encode(array("message" => "Unable to create product."));
    }
} else {
    // Set response code - 400 bad request
    http_response_code(400);
    
    // Tell the user
    echo json_encode(array("message" => "Unable to create product. Data is incomplete."));
}
?>