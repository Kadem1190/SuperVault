<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Include database and product model
include_once '../config/database.php';
include_once '../models/product.php';
include_once '../models/activity_log.php';

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Instantiate product object
$product = new Product($db);

// Get query parameters
$category = isset($_GET['category']) ? $_GET['category'] : null;
$search = isset($_GET['search']) ? $_GET['search'] : null;
$user_id = isset($_GET['user_id']) ? $_GET['user_id'] : null;

// Query products
$stmt = $product->read($category, $search);
$num = $stmt->rowCount();

// Log the activity if user_id is provided
if($user_id) {
    $activity_log = new ActivityLog($db);
    $activity_log->id = uniqid();
    $activity_log->user_id = $user_id;
    $activity_log->activity_type = "read";
    $activity_log->entity_type = "Product";
    $activity_log->entity_id = "all";
    $activity_log->description = "Viewed product list";
    $activity_log->create();
}

// Check if more than 0 record found
if($num > 0) {
    // Products array
    $products_arr = array();
    $products_arr["records"] = array();
    
    // Retrieve table contents
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        
        $product_item = array(
            "id" => $id,
            "name" => $name,
            "sku" => $sku,
            "description" => $description,
            "category" => $category_name,
            "category_id" => $category_id,
            "price" => $price,
            "image_url" => $image_url,
            "created_at" => $created_at,
            "updated_at" => $updated_at
        );
        
        array_push($products_arr["records"], $product_item);
    }
    
    // Set response code - 200 OK
    http_response_code(200);
    
    // Show products data in json format
    echo json_encode($products_arr);
} else {
    // Set response code - 404 Not found
    http_response_code(404);
    
    // Tell the user no products found
    echo json_encode(array("message" => "No products found."));
}
?>