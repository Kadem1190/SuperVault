<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include database and models
include_once '../config/database.php';
include_once '../models/product.php';
include_once '../models/activity_log.php';

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Instantiate product object
$product = new Product($db);

// Get product id and user id
$data = json_decode(file_get_contents("php://input"));

// Make sure ids are not empty
if(!empty($data->id) && !empty($data->user_id)) {
    // Set product id to be deleted
    $product->id = $data->id;
    
    // Get product details before deletion for logging
    $product->readOne();
    $product_name = $product->name;
    $product_sku = $product->sku;
    
    // Delete the product
    if($product->delete()) {
        // Log the activity
        $activity_log = new ActivityLog($db);
        $activity_log->id = uniqid();
        $activity_log->user_id = $data->user_id;
        $activity_log->activity_type = "delete";
        $activity_log->entity_type = "Product";
        $activity_log->entity_id = $product->id;
        $activity_log->description = "Deleted product: {$product_name} ({$product_sku})";
        $activity_log->create();
        
        // Set response code - 200 ok
        http_response_code(200);
        
        // Tell the user
        echo json_encode(array("message" => "Product was deleted."));
    } else {
        // Set response code - 503 service unavailable
        http_response_code(503);
        
        // Tell the user
        echo json_encode(array("message" => "Unable to delete product."));
    }
} else {
    // Set response code - 400 bad request
    http_response_code(400);
    
    // Tell the user
    echo json_encode(array("message" => "Unable to delete product. Product ID or User ID is missing."));
}
?>