<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include database and models
include_once '../config/database.php';
include_once '../models/transaction.php';
include_once '../models/inventory.php';
include_once '../models/activity_log.php';
include_once '../models/product.php';
include_once '../models/warehouse.php';

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Instantiate transaction object
$transaction = new Transaction($db);

// Get posted data
$data = json_decode(file_get_contents("php://input"));

// Make sure data is not empty
if(
    !empty($data->product_id) &&
    !empty($data->warehouse_id) &&
    !empty($data->user_id) &&
    !empty($data->type) &&
    isset($data->quantity)
) {
    // Begin transaction
    $db->beginTransaction();
    
    try {
        // Set transaction property values
        $transaction->id = uniqid();
        $transaction->product_id = $data->product_id;
        $transaction->warehouse_id = $data->warehouse_id;
        $transaction->destination_warehouse_id = $data->destination_warehouse_id ?? null;
        $transaction->user_id = $data->user_id;
        $transaction->type = $data->type;
        $transaction->quantity = $data->quantity;
        $transaction->notes = $data->notes ?? "";
        
        // Create the transaction
        if($transaction->create()) {
            // Update inventory based on transaction type
            $inventory = new Inventory($db);
            
            // Get product and warehouse details for logging
            $product = new Product($db);
            $product->id = $transaction->product_id;
            $product->readOne();
            
            $warehouse = new Warehouse($db);
            $warehouse->id = $transaction->warehouse_id;
            $warehouse->readOne();
            
            // Check if inventory record exists for this product and warehouse
            $query = "SELECT id, quantity FROM inventory WHERE product_id = ? AND warehouse_id = ? LIMIT 0,1";
            $stmt = $db->prepare($query);
            $stmt->bindParam(1, $transaction->product_id);
            $stmt->bindParam(2, $transaction->warehouse_id);
            $stmt->execute();
            
            if($stmt->rowCount() > 0) {
                // Update existing inventory
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $inventory->id = $row['id'];
                $old_quantity = $row['quantity'];
                
                // Calculate new quantity based on transaction type
                switch($transaction->type) {
                    case 'stock_in':
                        $inventory->quantity = $old_quantity + $transaction->quantity;
                        break;
                    case 'stock_out':
                        $inventory->quantity = $old_quantity - $transaction->quantity;
                        break;
                    case 'adjustment':
                        $inventory->quantity = $old_quantity + $transaction->quantity; // Can be negative
                        break;
                    case 'transfer':
                        $inventory->quantity = $old_quantity - $transaction->quantity;
                        break;
                }
                
                // Update inventory
                $inventory->update();
                
                // If it's a transfer, update or create destination inventory
                if($transaction->type == 'transfer' && $transaction->destination_warehouse_id) {
                    // Check if destination inventory exists
                    $query = "SELECT id, quantity FROM inventory WHERE product_id = ? AND warehouse_id = ? LIMIT 0,1";
                    $stmt = $db->prepare($query);
                    $stmt->bindParam(1, $transaction->product_id);
                    $stmt->bindParam(2, $transaction->destination_warehouse_id);
                    $stmt->execute();
                    
                    if($stmt->rowCount() > 0) {
                        // Update existing destination inventory
                        $row = $stmt->fetch(PDO::FETCH_ASSOC);
                        $dest_inventory = new Inventory($db);
                        $dest_inventory->id = $row['id'];
                        $dest_inventory->quantity = $row['quantity'] + $transaction->quantity;
                        $dest_inventory->update();
                    } else {
                        // Create new destination inventory
                        $dest_inventory = new Inventory($db);
                        $dest_inventory->id = uniqid();
                        $dest_inventory->product_id = $transaction->product_id;
                        $dest_inventory->warehouse_id = $transaction->destination_warehouse_id;
                        $dest_inventory->quantity = $transaction->quantity;
                        $dest_inventory->location = "Transfer";
                        $dest_inventory->create();
                    }
                    
                    // Get destination warehouse details for logging
                    $dest_warehouse = new Warehouse($db);
                    $dest_warehouse->id = $transaction->destination_warehouse_id;
                    $dest_warehouse->readOne();
                }
            } else {
                // Create new inventory record
                $inventory->id = uniqid();
                $inventory->product_id = $transaction->product_id;
                $inventory->warehouse_id = $transaction->warehouse_id;
                
                // Set quantity based on transaction type
                switch($transaction->type) {
                    case 'stock_in':
                    case 'adjustment':
                        $inventory->quantity = $transaction->quantity;
                        break;
                    case 'stock_out':
                    case 'transfer':
                        // Cannot remove from non-existent inventory
                        throw new Exception("Cannot perform {$transaction->type} on non-existent inventory.");
                }
                
                $inventory->location = $data->location ?? "Default";
                $inventory->create();
            }
            
            // Log the activity
            $activity_log = new ActivityLog($db);
            $activity_log->id = uniqid();
            $activity_log->user_id = $transaction->user_id;
            $activity_log->activity_type = "create";
            $activity_log->entity_type = "Transaction";
            $activity_log->entity_id = $transaction->id;
            
            // Create description based on transaction type
            switch($transaction->type) {
                case 'stock_in':
                    $activity_log->description = "Added {$transaction->quantity} units of {$product->name} to {$warehouse->name}";
                    break;
                case 'stock_out':
                    $activity_log->description = "Removed {$transaction->quantity} units of {$product->name} from {$warehouse->name}";
                    break;
                case 'adjustment':
                    $sign = $transaction->quantity >= 0 ? '+' : '';
                    $activity_log->description = "Adjusted inventory of {$product->name} in {$warehouse->name} by {$sign}{$transaction->quantity} units";
                    break;
                case 'transfer':
                    $activity_log->description = "Transferred {$transaction->quantity} units of {$product->name} from {$warehouse->name} to {$dest_warehouse->name}";
                    break;
            }
            
            $activity_log->create();
            
            // Commit transaction
            $db->commit();
            
            // Set response code - 201 created
            http_response_code(201);
            
            // Tell the user
            echo json_encode(array(
                "message" => "Transaction was created.",
                "id" => $transaction->id
            ));
        } else {
            throw new Exception("Unable to create transaction.");
        }
    } catch(Exception $e) {
        // Rollback transaction
        $db->rollBack();
        
        // Set response code - 503 service unavailable
        http_response_code(503);
        
        // Tell the user
        echo json_encode(array("message" => $e->getMessage()));
    }
} else {
    // Set response code - 400 bad request
    http_response_code(400);
    
    // Tell the user
    echo json_encode(array("message" => "Unable to create transaction. Data is incomplete."));
}
?>