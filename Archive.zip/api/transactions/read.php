<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Include database and transaction model
include_once '../config/database.php';
include_once '../models/transaction.php';
include_once '../models/activity_log.php';

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Instantiate transaction object
$transaction = new Transaction($db);

// Get query parameters
$type = isset($_GET['type']) ? $_GET['type'] : null;
$warehouse = isset($_GET['warehouse']) ? $_GET['warehouse'] : null;
$search = isset($_GET['search']) ? $_GET['search'] : null;
$user_id = isset($_GET['user_id']) ? $_GET['user_id'] : null;

// Query transactions
$stmt = $transaction->read($type, $warehouse, $search);
$num = $stmt->rowCount();

// Log the activity if user_id is provided
if($user_id) {
    $activity_log = new ActivityLog($db);
    $activity_log->id = uniqid();
    $activity_log->user_id = $user_id;
    $activity_log->activity_type = "read";
    $activity_log->entity_type = "Transaction";
    $activity_log->entity_id = "all";
    $activity_log->description = "Viewed transaction list";
    $activity_log->create();
}

// Check if more than 0 record found
if($num > 0) {
    // Transactions array
    $transactions_arr = array();
    $transactions_arr["records"] = array();
    
    // Retrieve table contents
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        
        $transaction_item = array(
            "id" => $id,
            "product_id" => $product_id,
            "product_name" => $product_name,
            "product_sku" => $sku,
            "warehouse_id" => $warehouse_id,
            "warehouse_name" => $warehouse_name,
            "destination_warehouse_id" => $destination_warehouse_id,
            "destination_warehouse_name" => $destination_warehouse_name,
            "user_id" => $user_id,
            "user_name" => $user_name,
            "type" => $type,
            "quantity" => $quantity,
            "notes" => $notes,
            "timestamp" => $timestamp
        );
        
        array_push($transactions_arr["records"], $transaction_item);
    }
    
    // Set response code - 200 OK
    http_response_code(200);
    
    // Show transactions data in json format
    echo json_encode($transactions_arr);
} else {
    // Set response code - 404 Not found
    http_response_code(404);
    
    // Tell the user no transactions found
    echo json_encode(array("message" => "No transactions found."));
}
?>