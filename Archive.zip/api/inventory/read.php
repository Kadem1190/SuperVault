<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Include database and inventory model
include_once '../config/database.php';
include_once '../models/inventory.php';
include_once '../models/activity_log.php';

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Instantiate inventory object
$inventory = new Inventory($db);

// Get query parameters
$warehouse = isset($_GET['warehouse']) ? htmlspecialchars(strip_tags($_GET['warehouse'])) : null;
$category = isset($_GET['category']) ? htmlspecialchars(strip_tags($_GET['category'])) : null;
$search = isset($_GET['search']) ? htmlspecialchars(strip_tags($_GET['search'])) : null;
$user_id = isset($_GET['user_id']) ? htmlspecialchars(strip_tags($_GET['user_id'])) : null;

// Query inventory
$stmt = $inventory->read($warehouse, $category, $search);
if (!$stmt) {
    // Set response code - 500 Internal Server Error
    http_response_code(500);
    echo json_encode(array("message" => "Failed to retrieve inventory."));
    exit();
}

$num = $stmt->rowCount();

// Log the activity if user_id is provided
if ($user_id) {
    $activity_log = new ActivityLog($db);
    $activity_log->id = uniqid();
    $activity_log->user_id = $user_id;
    $activity_log->activity_type = "read";
    $activity_log->entity_type = "Inventory";
    $activity_log->entity_id = "all";
    $activity_log->description = "Viewed inventory list";

    if (!$activity_log->create()) {
        // Log creation failed, but we don't want to stop the script
        error_log("Failed to create activity log for user_id: $user_id");
    }
}

// Check if more than 0 record found
if ($num > 0) {
    // Inventory array
    $inventory_arr = array();
    $inventory_arr["records"] = array();
    
    // Retrieve table contents
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        
        $inventory_item = array(
            "id" => $id,
            "product_id" => $product_id,
            "product_name" => $product_name,
            "sku" => $sku,
            "category" => $category_name,
            "warehouse_id" => $warehouse_id,
            "warehouse_name" => $warehouse_name,
            "quantity" => $quantity,
            "location" => $location,
            "status" => $quantity <= 0 ? "outOfStock" : ($quantity < 10 ? "low" : "available"),
            "last_updated" => $last_updated
        );
        
        array_push($inventory_arr["records"], $inventory_item);
    }
    
    // Set response code - 200 OK
    http_response_code(200);
    
    // Show inventory data in json format
    echo json_encode($inventory_arr);
} else {
    // Set response code - 404 Not found
    http_response_code(404);
    
    // Tell the user no inventory found
    echo json_encode(array("message" => "No inventory items found."));
}
?>