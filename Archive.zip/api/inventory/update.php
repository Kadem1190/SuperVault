<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include database and models
include_once '../config/database.php';
include_once '../models/inventory.php';
include_once '../models/activity_log.php';
include_once '../models/product.php';
include_once '../models/warehouse.php';

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Instantiate inventory object
$inventory = new Inventory($db);

// Get posted data
$data = json_decode(file_get_contents("php://input"));

// Make sure id is not empty and user_id is provided
if(!empty($data->id) && !empty($data->user_id)) {
    // Get inventory details before update for logging
    $inventory->id = $data->id;
    $inventory->readOne();
    $old_quantity = $inventory->quantity;
    
    // Get product and warehouse details for logging
    $product = new Product($db);
    $product->id = $inventory->product_id;
    $product->readOne();
    
    $warehouse = new Warehouse($db);
    $warehouse->id = $inventory->warehouse_id;
    $warehouse->readOne();
    
    // Set inventory property values
    $inventory->quantity = $data->quantity;
    $inventory->location = $data->location;
    
    // Update the inventory
    if($inventory->update()) {
        // Log the activity
        $activity_log = new ActivityLog($db);
        $activity_log->id = uniqid();
        $activity_log->user_id = $data->user_id;
        $activity_log->activity_type = "update";
        $activity_log->entity_type = "Inventory";
        $activity_log->entity_id = $inventory->id;
        
        $quantity_change = $inventory->quantity - $old_quantity;
        $change_text = $quantity_change > 0 ? "+$quantity_change" : "$quantity_change";
        
        $activity_log->description = "Updated inventory for {$product->name}: {$change_text} units in {$warehouse->name}";
        $activity_log->create();
        
        // Set response code - 200 ok
        http_response_code(200);
        
        // Tell the user
        echo json_encode(array("message" => "Inventory was updated."));
    } else {
        // Set response code - 503 service unavailable
        http_response_code(503);
        
        // Tell the user
        echo json_encode(array("message" => "Unable to update inventory."));
    }
} else {
    // Set response code - 400 bad request
    http_response_code(400);
    
    // Tell the user
    echo json_encode(array("message" => "Unable to update inventory. Data is incomplete."));
}
?>